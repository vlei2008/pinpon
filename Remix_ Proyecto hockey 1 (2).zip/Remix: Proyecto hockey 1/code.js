var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----



 var gameState="serve";
 //crear jugador
 var striker = createSprite(200,200,10,10);
striker.shapeColor = "blue";
//crear puntos
var score=0;
var puntos=0;
//crear porterias
var goal1=createSprite(200,18,100,20);
goal1.shapeColor=("yellow");
var goal2=createSprite(200,382,100,20);
goal2.shapeColor=("yellow");
//crear jugadores
var playerMallet = createSprite(200,50,50,10);
playerMallet.shapeColor = "black";

var computerMallet = createSprite(200,350,50,10);
computerMallet.shapeColor = "black";

// hacer la cancha
var boundary1 = createSprite(200,0,400,10);
boundary1.shapeColor = "black";
var boundary2 = createSprite(200,400,400,10);
boundary2.shapeColor = "black";
var boundary3 = createSprite(0,200,10,400);
boundary3.shapeColor = "black";
var boundary4 = createSprite(400,200,10,400);
boundary4.shapeColor = "black";
function draw() {
  background("pink");
  //la linea de en medio
  for (i=0;i<400;i=i+35){
    line(i,200,i+17,200);
  }
  //para que me marque el principio
 if (gameState=="serve"){
   textSize(17);
   text("Space para empezar",147,120);
   stroke("purple");
   if (keyDown("space")){
     striker.velocityX=5;
     striker.velocityY=5;
     gameState="play";
   }
 }
 //se detenga cada que marca punto
 if (striker.isTouching(goal1))

 {
striker.velocityY=0;
striker.velocityX=0;
///CON ESTO LA PELOTA REGRESA AL CENTRO Y VUELVES AL ESTADO DEL JUEGO PARA SERVE
//ME PARECE QUE SOLO TE HARÍA FALTA AGREGAR EL PUNTO
  striker.x = 200;
  striker.y = 200;
   puntos=puntos+1;
gameState="serve";
 }
  if (striker.isTouching(goal2))
  
 {
striker.velocityY=0;
striker.velocityX=0;
///CON ESTO LA PELOTA REGRESA AL CENTRO Y VUELVES AL ESTADO DEL JUEGO PARA SERVE
//ME PARECE QUE SOLO TE HARÍA FALTA AGREGAR EL PUNTO
striker.x = 200;
  striker.y = 200;
  score=score+1;
  gameState="serve";
  


 }
 //para que mientras este en funcion todo se mueva
 if (gameState=="play"){
   textSize(17);
   text("Estamos jugando",147,120);
   computerMallet.x=World.mouseX;
   playerMallet.x=striker.x;
 }
  //principio del final
 if (puntos==5){
   gameState="end";
 }
  if (score==5){
   gameState="end";
 }
 //el final
 if (gameState=="end")
 {
   textSize(17);
   text("Juego terminado",147,120);
   striker.velocityX=0;
   striker.velocityY=0;
   
 }
//crear marca de puntos
textSize(30);
text(+score,24,182);
textSize(30);
text(+puntos,24,235);
 if (striker.isTouching(goal1)){
   score=score+1;
 }
 if (striker.isTouching(goal2)){
   puntos=puntos+1;
 }
 //para que cuando llegue a 5 se detenga
 if (keyDown("enter")){
   striker.setSpeedAndDirection(200,200,0,0);
   
   
 }
createEdgeSprites();
striker.bounceOff(edges);
goal1.bounceOff(edges);
goal2.bounceOff(edges);
striker.bounceOff(playerMallet);
striker.bounceOff(computerMallet);
striker.bounceOff(goal1);
striker.bounceOff(goal2);
  
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
